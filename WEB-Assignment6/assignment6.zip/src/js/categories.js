/**
 * WEB222 – Assignment 05
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Renan de Alencar Queiroz
 *      Student ID: 129280236
 *      Date:       Jul 29, 2024
 */

window.categories = [
  /*
    { id: "c1", name: "Category 1" },
   */
  { id: "Cat01", name: "Tennis Racquets", image: "./images/TennisRacquet.png" },
  { id: "Cat02", name: "Tennis Balls", image: "./images/TennisBalls.jpeg" },
  { id: "Cat03", name: "Shoes", image: "./images/TennisShoes.jpeg" },
  { id: "Cat04", name: "Bags", image: "./images/TennisBags.jpeg" },
  { id: "Cat05", name: "Strings", image: "./images/TennisStrings.jpeg" },
];
